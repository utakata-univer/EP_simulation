#ifndef LATTICE_H
#define LATTICE_H

#define PI 3.14159265358979323846
#define L 4
#define V (L*L*L*L)

#ifdef CONTROL 
#define EXTERN 
#undef CONTROL
#else
#define EXTERN extern
#endif
 
EXTERN double a_0[L][L][L][L][4],a_1[L][L][L][L][4],a_2[L][L][L][L][4],a_3[L][L][L][L][4],k[L][L][L][L][4],p_0[L][L][L][L][4][4],p_1[L][L][L][L][4][4],p_2[L][L][L][L][4][4],p_3[L][L][L][L][4][4],q_0[L][L][L][L][4][4],q_1[L][L][L][L][4][4],q_2[L][L][L][L][4][4],q_3[L][L][L][L][4][4],r_0[L][L][L][L][4][4],r_1[L][L][L][L][4][4],r_2[L][L][L][L][4][4],r_3[L][L][L][L][4][4],s_0[L][L][L][L][4][4],s_1[L][L][L][L][4][4],s_2[L][L][L][L][4][4],s_3[L][L][L][L][4][4],k_0[L][L][L][L][4],k_1[L][L][L][L][4],k_2[L][L][L][L][4],k_3[L][L][L][L][4];

#endif
