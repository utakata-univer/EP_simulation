#include "math.h"
#include "ranlxd.h"
#include "su2.h"

static double beta;
static int ntraj;

void initialize(void)
{
    int nx,ny,nz,nt,mu;
    
       for (nx=1;nx<L+1;nx++)
    {
       for (ny=1;ny<L+1;ny++)
    {
       for (nz=1;nz<L+1;nz++)
    {
       for (nt=1;nt<L+1;nt++)
    {
       for (mu=0;mu<4;mu++)
       {    
	    a_0[nx][ny][nz][nt][mu]=1;
            a_1[nx][ny][nz][nt][mu]=0;
            a_2[nx][ny][nz][nt][mu]=0;
            a_3[nx][ny][nz][nt][mu]=0;
       }
       
    }
       
    }
       
    }

    }
    
}	    


void heatbath()
{
    int isweep;

    for (isweep=0;isweep<ntraj;isweep++)
    {
     void choose_avector();
    }

}


void choose_avector()
{
    int nx,ny,nz,nt,mu;
    double b,c,r,x[L*L*L*L*L+L*L*L*L+L*L*L+L*L+4],y[L*L*L*L*L+L*L*L*L+L*L*L+L*L+4],theta[L*L*L*L*L+L*L*L*L+L*L*L+L*L+4],phi[L*L*L*L*L+L*L*L*L+L*L*L+L*L+4],delta[L+1][L+1][L+1][L+1][4];
	    
    ranlxd(x,L*L*L*L*L+L*L*L*L+L*L*L+L*L+4);

    ranlxd(y,L*L*L*L*L+L*L*L*L+L*L*L+L*L+4);


   	
        for (nx=1;nx<L+1;nx++)
    {
        for (ny=1;ny<L+1;ny++)
    {
        for (nz=1;nz<L+1;nz++)
    {
        for (nt=1;nt<L+1;nt++)
    {
        for (mu=0;mu<4;mu++)
    {

    make_k();	    
	    
	do {   
               ranlxd(&c,1);

	       ranlxd(&r,1);

               b=c*(1-exp(-2*beta*k[nx][ny][nz][nt][mu]))+exp(-2*beta*k[nx][ny][nz][nt][mu]);

               a_0[nx][ny][nz][nt][mu]=1+log(b)/(beta*k[nx][ny][nz][nt][mu]);
		       
	       delta[nx][ny][nz][nt][mu]=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu]);

      	    } while (delta[nx][ny][nz][nt][mu] < r);	


    theta[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]=acos(2*x[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]-1);
    phi[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]=PI*y[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]-PI/2;


        a_1[nx][ny][nz][nt][mu]=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu])*cos(theta[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu])*cos(phi[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]);
        a_2[nx][ny][nz][nt][mu]=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu])*cos(theta[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu])*sin(phi[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]);
        a_3[nx][ny][nz][nt][mu]=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu])*sin(theta[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]);


    }
    
    }

    }

    }

    }
	
}
    



