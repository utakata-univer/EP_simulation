#ifndef LATTICE_H
#define LATTICE_H

#define PI 3.14159265358979323846
#define L 4
#define V (L*L*L*L)

#ifdef CONTROL 
#define EXTERN 
#undef CONTROL
#else
#define EXTERN extern
#endif

EXTERN double a_0[L+2][L+2][L+2][L+2][4],a_1[L+2][L+2][L+2][L+2][4],a_2[L+2][L+2][L+2][L+2][4],a_3[L+2][L+2][L+2][L+2][4],k[L+1][L+1][L+1][L+1][4];

#endif
