#include "math.h"
#include "ranlxd.h"
#include "su2.h"

void initialize(void)
{
    int nx,ny,nz,nt,mu;
    
       for (nx=1;nx<L+1;nx++)
    {
       for (ny=1;ny<L+1;ny++)
    {
       for (nz=1;nz<L+1;nz++)
    {
       for (nt=1;nt<L+1;nt++)
    {
       for (mu=0;mu<4;mu++)
       {    
	    a_0[nx][ny][nz][nt][mu]=1;
            a_1[nx][ny][nz][nt][mu]=0;
            a_2[nx][ny][nz][nt][mu]=0;
            a_3[nx][ny][nz][nt][mu]=0;
       }
       
    }
       
    }
       
    }

    }
    
}	    

void triala_0(void)
{
    int nx,ny,nz,nt,mu;
    double b[L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4],c[L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4];

    make_k();

    ranlxd(c,L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4);

    for (nx=1;nx<L+1;nx++)
    {
       for (ny=1;ny<L+1;ny++)
    {
       for (nz=1;nz<L+1;nz++)
    {
       for (nt=1;nt<L+1;nt++)
    {
       for (mu=0;mu<4;mu++)
       {
	b[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]=c[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]*(1-exp(-2*beta*k[nx][ny][nz][nt][mu]))+exp(-2*beta*k[nx][ny][nz][nt][mu]);
    
	a_0[nx][ny][nz][nt][mu]=1+log(b[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu])/(beta*k[nx][ny][nz][nt][mu]);
        }
    
    }

    }

    }

    }   
    
}

void heatbath(void)
{
    int isweep,nx,ny,nz,nt,mu;
    double r,delta,a_0old[L+1][L+1][L+1][L+1][4];

    for (isweep=0;isweep<ntraj;isweep++)
    {	
        for (nx=1;nx<L+1;nx++)
    {
        for (ny=1;ny<L+1;ny++)
    {
        for (nz=1;nz<L+1;nz++)
    {
        for (nt=1;nt<L+1;nt++)
    {
        for (mu=0;mu<4;mu++)
    {

     a_0[nx][ny][nz][nt][mu]=a_0old[nx][ny][nz][nt][mu];

	do {
               a_0[nx][ny][nz][nt][mu]=a_0old[nx][ny][nz][nt][mu];
       	       triala_0();
	       ranlxd(&r,1);		       
	       delta=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu]);

      	    } while (delta < r);

    }
    
    }

    }

    }

    }

    }	
	
}
    


void choose_avector(void)
{
    int i,nx,ny,nz,nt,mu;
    double x[L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4],y[L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4],theta[L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4],phi[L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4];
 
    ranlxd(x,L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4);

    ranlxd(y,L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4);

    for (i=0;i<L*L*L*L*L+2*L*L*L*L+2*L*L*L+2*L*L+L+4;i++)
    {
	theta[i]=2*PI*x[i];
	phi[i]=PI*y[i]-PI/2;
    }

       for (nx=1;nx<L+1;nx++)
    {
       for (ny=1;ny<L+1;ny++)
    {
       for (nz=1;nz<L+1;nz++)
    {
       for (nt=1;nt<L+1;nt++)
    {
       for (mu=0;mu<4;mu++)
    {
	a_1[nx][ny][nz][nt][mu]=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu])*sin(theta[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu])*cos(phi[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]);
        a_2[nx][ny][nz][nt][mu]=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu])*sin(theta[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu])*cos(phi[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]);
	a_3[nx][ny][nz][nt][mu]=sqrt(1-a_0[nx][ny][nz][nt][mu]*a_0[nx][ny][nz][nt][mu])*cos(theta[L*L*L*L*nx+L*L*L*ny+L*L*nz+L*nt+mu]);
   
    }
    
    }

    }

    }

    }

}


