#ifndef SU2_H
#define SU2_H
#include "stdio.h"
#include "stdlib.h"
#include "lattice.h"
#include "ranlxd.h"
#include "math.h"

double beta;
int ntraj;

void initialize();
void make_k();
double plaquette();
void choose_avector();
void heatbath();


#endif
