#ifndef SU2_H
#define SU2_H
#include "stdio.h"
#include "stdlib.h"
#include "lattice.h"
#include "ranlxd.h"
#include "math.h"

void initialize();
void make_k();
double plaquette();
void heatbath();


#endif
